package test

import (
	"testing"
	"fmt"

	//"github.com/Azure/azure-sdk-for-go/services/sql/mgmt/2014-04-01/sql"
	//"github.com/gruntwork-io/terratest/modules/azure"
	"github.com/gruntwork-io/terratest/modules/azure"
	"github.com/gruntwork-io/terratest/modules/terraform"
	"github.com/stretchr/testify/assert"
)

db_instance_domain = ""
db_instance_domain_iam_role_name 
db_instance_endpoint
db_instance_engine
db_instance_engine_version_actual 
db_instance_port
db_instance_resource_id
db_instance_name

Vishnu - 8 nine 1 nine 764774
Charan - eight nine 1 seven 689154  




Royaldkzero


func TestTerraformAzureMSSQLDBExample(t *testing.T) {
	t.Parallel()

	subscriptionID := "b0244146-b372-4dcd-8f03-4736e541def7"

	// Configure Terraform setting up a path to Terraform code.
	terraformOptions := &terraform.Options{
		// The path to where our Terraform code is located.
		TerraformDir: ".",
	}

	// At the end of the test, run `terraform destroy` to clean up any resources that were created
	defer terraform.Destroy(t, terraformOptions)

	// Run `terraform init` and `terraform apply`. Fail the test if there are any errors.
	terraform.InitAndApply(t, terraformOptions)

	// Run `terraform output` to get the values of output variables
	expectedMSSQLServerID := terraform.Output(t, terraformOptions, "mssql_server_id")
	expectedMSSQLServerName := terraform.Output(t, terraformOptions, "mssql_server_name")

	expectedMSSQLServerFullDomainName := terraform.Output(t, terraformOptions, "mssql_server_fqdn")
	expectedMSSQLDBName := terraform.Output(t, terraformOptions, "mssql_database_name")

	expectedMSSQLDBID := terraform.Output(t, terraformOptions, "mssql_database_id")
	expectedResourceGroupName := terraform.Output(t, terraformOptions, "resource_group_name")
	expectedMSSQLDBStatus := "Online"

	// Get the SQL server details and assert them against the terraform output
	actualSQLServer := azure.GetSQLServer(t, expectedResourceGroupName, expectedMSSQLServerName, subscriptionID)

	fmt.Println("expectedMSSQLServerID: ", expectedMSSQLServerID)
	fmt.Println("actualSQLServerID: ", *actualSQLServer.ID)
	fmt.Println("expectedMSSQLServerFullDomainName: ", expectedMSSQLServerFullDomainName)
	fmt.Println("actualMSSQLServerFullDomainName: ", *actualSQLServer.FullyQualifiedDomainName)

	assert.Equal(t, expectedMSSQLServerID, *actualSQLServer.ID)
	assert.Equal(t, expectedMSSQLServerFullDomainName, *actualSQLServer.FullyQualifiedDomainName)
	//assert.Equal(t, sql.ServerStateReady, actualSQLServer.State)

	// Get the SQL server DB details and assert them against the terraform output
	actualSQLDatabase := azure.GetSQLDatabase(t, expectedResourceGroupName, expectedMSSQLServerName, expectedMSSQLDBName, subscriptionID)

	fmt.Println("expectedMSSQLDBID: ", expectedMSSQLDBID)
	fmt.Println("actualMSSQLDBID: ", *actualSQLDatabase.ID)
	fmt.Println("expectedMSSQLDBStatus: ", expectedMSSQLDBStatus)
	fmt.Println("actualMSSQLDBStatus: ", *actualSQLDatabase.Status)

	assert.Equal(t, expectedMSSQLDBID, *actualSQLDatabase.ID)
	assert.Equal(t, expectedMSSQLDBStatus, *actualSQLDatabase.Status)
}
